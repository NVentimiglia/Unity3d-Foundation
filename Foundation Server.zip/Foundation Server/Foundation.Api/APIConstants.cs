namespace Foundation.Server.Api
{
    public class APIConstants
    {
        public static string APPLICATIONID = "APPLICATIONID";
        public static string SESSION = "SESSION";
        public static string AUTHORIZATION = "AUTHORIZATION";
        public static string FACEBOOK = "facebook";
    }
}