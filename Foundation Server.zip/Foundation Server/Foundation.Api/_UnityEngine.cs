namespace UnityEngine
{
    public struct Color
    {
        public float a;
        public float b;
        public float r;
        public float g;
    }
}
